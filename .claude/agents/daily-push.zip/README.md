# Daily Push - 每日消息推送 Agent

一个自动化的每日消息推送系统，可获取天气、新闻、IT资讯并发送到指定邮箱。

## 功能特性

- **天气推送**: 获取指定城市各区域实时天气
- **新闻推送**: 获取每日热点新闻（每日简报）
- **IT 资讯**: 获取科技行业最新动态
- **邮件发送**: 精美的 HTML 邮件格式
- **定时任务**: 支持每天定时自动推送

## 快速开始

### 第一步：获取 API Key

#### 1. 和风天气 API
1. 访问 https://dev.qweather.com/ 注册
2. 创建项目 → Web API → 免费订阅
3. 复制 API Key 和自定义 API Host

#### 2. 天行数据 API
1. 访问 https://www.tianapi.com/ 注册
2. 申请 `bulletin` 和 `it` 接口
3. 复制 API Key

### 第二步：配置 SMTP

QQ邮箱配置：
1. QQ邮箱 → 设置 → 账户 → 开启 SMTP
2. 生成授权码

### 第三步：安装

1. 解压到目标目录，如 `D:\daily-push`

2. 复制配置文件到 Claude Code 项目：
   ```
   将 .claude 文件夹复制到你的项目根目录
   ```

3. 修改 `.claude/settings.local.json`：
   ```json
   {
     "env": {
       "SMTP_HOST": "smtp.qq.com",
       "SMTP_PORT": "587",
       "SMTP_USER": "你的邮箱",
       "SMTP_PASS": "你的授权码",
       "EMAIL_RECIPIENTS": "收件人邮箱",
       "QWEATHER_API_KEY": "和风天气Key",
       "QWEATHER_API_HOST": "你的API Host",
       "TIANAPI_KEY": "天行数据Key"
     }
   }
   ```

4. 修改 `.claude/skills/daily-push.md` 中的 `{{SCRIPTS_PATH}}`

5. 安装依赖：
   ```bash
   pip install requests
   ```

### 第四步：测试

```
/daily-push --test
```

### 第五步：设置定时任务

```
/cron 0 8 * * * /daily-push
```

## 文件说明

```
daily-push/
├── .claude/
│   ├── agents/daily-push.md      # Agent 定义
│   ├── skills/daily-push.md      # Skill 定义（需修改路径）
│   └── settings.local.json       # 配置文件（需填写）
├── scripts/
│   ├── main.py                   # 主脚本
│   ├── weather.py                # 天气获取
│   ├── news.py                   # 新闻获取
│   └── send_email.py             # 邮件发送
└── README.md                     # 本文档
```

## 自定义

### 修改天气城市

编辑 `scripts/weather.py` 中的 `GUANGZHOU_LOCATIONS` 和 `MAOMING_LOCATIONS`

### 修改邮件样式

编辑 `scripts/send_email.py` 中的 CSS 样式

## 环境变量

| 变量 | 说明 |
|------|------|
| SMTP_HOST | SMTP 服务器 |
| SMTP_PORT | SMTP 端口 |
| SMTP_USER | 发件邮箱 |
| SMTP_PASS | 授权码 |
| EMAIL_RECIPIENTS | 收件人 |
| QWEATHER_API_KEY | 和风天气 Key |
| QWEATHER_API_HOST | 和风天气 Host |
| TIANAPI_KEY | 天行数据 Key |

## 故障排除

- **天气 403**: 检查 API Host 是否正确
- **邮件失败**: 检查 SMTP 配置和授权码
- **新闻为空**: 检查天行数据接口权限
