# Daily Push Agent

每日消息推送自动化 Agent。

## 配置

- **subagent_type**: general-purpose
- **model**: sonnet

## 描述

每日自动获取天气、新闻、IT资讯并发送到指定邮箱。

## 功能

1. 天气获取 - 和风天气 API
2. 新闻获取 - 天行数据每日简报
3. IT 资讯 - 天行数据 IT 接口
4. 邮件发送 - SMTP

## 环境变量

| 变量 | 必需 |
|------|------|
| QWEATHER_API_KEY | ✅ |
| QWEATHER_API_HOST | ✅ |
| TIANAPI_KEY | ✅ |
| SMTP_HOST | ✅ |
| SMTP_PORT | ✅ |
| SMTP_USER | ✅ |
| SMTP_PASS | ✅ |
| EMAIL_RECIPIENTS | ✅ |
