# Daily Push Skill

每日消息推送，使用 `/daily-push` 触发。

## 参数

- `--test`: 测试模式，只打印数据不发送邮件

## 使用方法

1. 先修改本文件中的 `{{SCRIPTS_PATH}}` 为你的 scripts 目录实际路径
2. 确保 settings.local.json 中已配置所有环境变量

## 执行命令

### 发送邮件
```bash
cd {{SCRIPTS_PATH}} && set PYTHONIOENCODING=utf-8 && python main.py
```

### 测试模式
```bash
cd {{SCRIPTS_PATH}} && set PYTHONIOENCODING=utf-8 && python main.py --test
```

## 示例

将 `{{SCRIPTS_PATH}}` 替换为实际路径，例如：
```bash
cd D:/my-project/scripts && set PYTHONIOENCODING=utf-8 && python main.py
```

## 前置条件

- Python 3.8+
- requests 库
- 已配置 settings.local.json
